import CringeAnalyzer from '@/components/cringe-analyzer';

export default function Home() {
  return <CringeAnalyzer />;
}
